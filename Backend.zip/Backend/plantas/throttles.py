from rest_framework.throttling import AnonRateThrottle

class BusquedaPorIPThrottle(AnonRateThrottle):
    scope = "busquedas"